package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BackendParsingTest {
    @Test
    fun feedAnswerBecomesMediaItems() {
        val json = """{"query":"","page":1,"has_more":true,"message":"2 results.","items":[
            {"id":"v6abc12-funny-cats","title":"Funny cats","uploader":"CatChannel","thumbnail_url":"https://t/x.jpg","duration":"3:21",
             "source":"Rumble","source_id":"rumble","media_type":"video","page_url":"https://rumble.com/v6abc12-funny-cats.html","media_url":null},
            {"id":"x8abc12","title":"T","uploader":"O","thumbnail_url":null,"duration":null,"source":"Dailymotion","source_id":"dailymotion",
             "media_type":"video","page_url":"https://www.dailymotion.com/video/x8abc12","media_url":null}]}"""
        val r = parseBackendFeed(json)
        assertTrue(r.hasMore)
        assertEquals(2, r.items.size)
        assertEquals("rumble:v6abc12-funny-cats", r.items[0].key)
        assertEquals("3:21", r.items[0].duration)
        assertNull(r.items[0].mediaUrl)
        assertNull(r.items[1].thumbnailUrl)
        assertEquals("", r.items[1].duration)
        assertFalse(parseBackendFeed("""{"items":[],"message":"Nothing"}""").hasMore)
    }

    @Test
    fun streamAnswerKeepsDirectLinksAndWebPlayer() {
        val r = parseStream(
            """{"source_id":"rumble","media_url":"https://r/720.mp4","media_urls":["https://r/720.mp4","https://r/360.mp4","http://insecure/x.mp4"],
            "media_type":"video","embed_url":"https://rumble.com/embed/v5abcd/","ttl_seconds":1800}"""
        )
        assertEquals(listOf("https://r/720.mp4", "https://r/360.mp4"), r.urls)
        assertEquals("https://rumble.com/embed/v5abcd/", r.embedUrl)
        val webOnly = parseStream("""{"source_id":"vimeo","media_url":null,"media_urls":[],"embed_url":"https://player.vimeo.com/video/1?autoplay=1"}""")
        assertTrue(webOnly.urls.isEmpty())
        assertEquals("https://player.vimeo.com/video/1?autoplay=1", webOnly.url)
    }

    @Test
    fun streamAnswerWithNothingPlayableIsAnError() {
        try {
            parseStream("""{"source_id":"x","media_url":null,"media_urls":[],"embed_url":null}""")
        } catch (e: IllegalStateException) {
            return
        }
        throw AssertionError("expected IllegalStateException")
    }

    @Test
    fun homeChipsStartWithAllAndHaveUniqueIds() {
        assertNull(SourceChips.first().id)
        assertEquals(SourceChips.size, SourceChips.map { it.id }.toSet().size)
        assertTrue(SourceChips.any { it.id == "rumble" })
    }
}
