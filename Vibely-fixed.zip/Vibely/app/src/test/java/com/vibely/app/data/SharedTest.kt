package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SharedTest {
    @Test
    fun runtimeFormattingAndSeconds() {
        assertEquals("2:05", formatRuntime("125"))
        assertEquals("1:02:05", formatRuntime("3725.4"))
        assertEquals("12:30", formatRuntime("12:30"))
        assertNull(formatRuntime(null))
        assertNull(formatRuntime("abc"))
        assertNull(formatRuntime("0"))
        assertEquals(205, runtimeSeconds("00:03:25"))
        assertEquals(205, runtimeSeconds("3:25"))
        assertEquals(205, runtimeSeconds("205.45"))
        assertNull(runtimeSeconds(""))
    }

    @Test
    fun downloadFileNamesAreSafe() {
        assertEquals("v6abc12-cats_clip.mp4", downloadFileName("v6abc12-cats", "clip.mp4"))
        assertEquals("a_b_c_d_.webm", downloadFileName("a/b", "c d?.webm"))
    }
}
