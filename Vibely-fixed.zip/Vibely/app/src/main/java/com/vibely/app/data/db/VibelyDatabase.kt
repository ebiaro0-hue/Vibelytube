package com.vibely.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        MediaEntity::class,
        HistoryEntity::class,
        LikeEntity::class,
        SavedEntity::class,
        PlaylistEntity::class,
        PlaylistItemEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class VibelyDatabase : RoomDatabase() {
    abstract fun library(): LibraryDao

    companion object {
        /** v1 -> v2: playlists get a stable cloudId (random hex for existing rows) for cross-device sync. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playlists ADD COLUMN cloudId TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE playlists SET cloudId = lower(hex(randomblob(16)))")
            }
        }

        @Volatile
        private var instance: VibelyDatabase? = null

        fun get(context: Context): VibelyDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    VibelyDatabase::class.java,
                    "vibely.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
