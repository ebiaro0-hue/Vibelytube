package com.vibely.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.vibely.app.data.DownloadEntry
import com.vibely.app.data.DownloadStatus
import com.vibely.app.data.DownloadsRepository
import com.vibely.app.data.LibraryRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface LibraryPage {
    data object Root : LibraryPage
    data object History : LibraryPage
    data object Liked : LibraryPage
    data object Saved : LibraryPage
    data object Playlists : LibraryPage
    data object Downloads : LibraryPage
    data class PlaylistDetail(val id: Long, val name: String) : LibraryPage
}

/** Library tab: root menu plus History / Liked / Saved / Playlists pages backed by the local database. */
@Composable
fun LibraryTab(
    library: LibraryRepository,
    page: LibraryPage,
    onPageChange: (LibraryPage) -> Unit,
    onPlay: (MediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()

    BackHandler(enabled = page != LibraryPage.Root) {
        onPageChange(if (page is LibraryPage.PlaylistDetail) LibraryPage.Playlists else LibraryPage.Root)
    }

    when (page) {
        LibraryPage.Root -> LibraryRoot(
            modifier = modifier,
            onOpen = onPageChange
        )

        LibraryPage.Downloads -> DownloadsPage(
            onBack = { onPageChange(LibraryPage.Root) },
            onPlay = onPlay,
            modifier = modifier
        )

        LibraryPage.History -> {
            val entries by remember { library.history() }.collectAsStateWithLifecycle(emptyList<MediaItem>())
            ItemListPage(
                title = "History",
                entries = entries,
                emptyText = "Videos you watch will appear here.",
                onBack = { onPageChange(LibraryPage.Root) },
                onPlay = onPlay,
                modifier = modifier,
                actionLabel = "Clear all",
                onAction = { scope.launch { library.clearHistory() } },
                onRemove = { item -> scope.launch { library.removeFromHistory(item) } }
            )
        }

        LibraryPage.Liked -> {
            val entries by remember { library.liked() }.collectAsStateWithLifecycle(emptyList<MediaItem>())
            ItemListPage(
                title = "Liked videos",
                entries = entries,
                emptyText = "Tap Like on a video and it will show up here.",
                onBack = { onPageChange(LibraryPage.Root) },
                onPlay = onPlay,
                modifier = modifier,
                onRemove = { item -> scope.launch { library.setLiked(item, false) } }
            )
        }

        LibraryPage.Saved -> {
            val entries by remember { library.saved() }.collectAsStateWithLifecycle(emptyList<MediaItem>())
            ItemListPage(
                title = "Saved",
                entries = entries,
                emptyText = "Tap Save on a video to keep it here.",
                onBack = { onPageChange(LibraryPage.Root) },
                onPlay = onPlay,
                modifier = modifier,
                onRemove = { item -> scope.launch { library.setSaved(item, false) } }
            )
        }

        LibraryPage.Playlists -> PlaylistsPage(
            library = library,
            onBack = { onPageChange(LibraryPage.Root) },
            onOpen = { p -> onPageChange(LibraryPage.PlaylistDetail(p.id, p.name)) },
            modifier = modifier
        )

        is LibraryPage.PlaylistDetail -> {
            val entries by remember(page.id) { library.playlistItems(page.id) }
                .collectAsStateWithLifecycle(emptyList<MediaItem>())
            ItemListPage(
                title = page.name,
                entries = entries,
                emptyText = "This playlist is empty. Open a video and tap Playlist to add it.",
                onBack = { onPageChange(LibraryPage.Playlists) },
                onPlay = onPlay,
                modifier = modifier,
                onRemove = { item -> scope.launch { library.removeFromPlaylist(page.id, item) } }
            )
        }
    }
}

@Composable
private fun LibraryRoot(
    modifier: Modifier,
    onOpen: (LibraryPage) -> Unit
) {
    Column(modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Text("Library", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your videos and listening activity", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        val entries = listOf(
            Triple(Icons.Default.History, "History", "Videos you recently watched") to { onOpen(LibraryPage.History) },
            Triple(Icons.Default.Download, "Downloads", "Saved on this device for offline") to { onOpen(LibraryPage.Downloads) },
            Triple(Icons.Default.PlaylistPlay, "Playlists", "Your saved collections") to { onOpen(LibraryPage.Playlists) },
            Triple(Icons.Default.Favorite, "Liked videos", "Videos you liked") to { onOpen(LibraryPage.Liked) },
            Triple(Icons.Default.Bookmark, "Saved", "Your bookmarked videos") to { onOpen(LibraryPage.Saved) }
        )
        entries.forEach { (info, action) ->
            val (icon, title, subtitle) = info
            Row(
                Modifier.fillMaxWidth().clickable(onClickLabel = "Open $title", onClick = action).padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, tint = Accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Color.Gray, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
            }
            HorizontalDivider(color = Color(0xFF303137))
        }
    }
}

@Composable
private fun PageHeader(
    title: String,
    onBack: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
        }
        Text(
            title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

@Composable
private fun ItemListPage(
    title: String,
    entries: List<MediaItem>,
    emptyText: String,
    onBack: () -> Unit,
    onPlay: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    onRemove: ((MediaItem) -> Unit)? = null
) {
    Column(modifier.fillMaxSize().background(Bg)) {
        PageHeader(title, onBack) {
            if (actionLabel != null && onAction != null && entries.isNotEmpty()) {
                TextButton(onClick = onAction) { Text(actionLabel, color = Accent) }
            }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(emptyText, color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(entries, key = { it.key }) { item ->
                    CompactRow(item, onClick = { onPlay(item) }, onRemove = onRemove)
                }
            }
        }
    }
}

@Composable
internal fun CompactRow(
    item: MediaItem,
    onClick: () -> Unit,
    onRemove: ((MediaItem) -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClickLabel = "Play ${item.title}", onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(128.dp).height(72.dp).clip(RoundedCornerShape(10.dp)).background(SurfaceDark),
            contentAlignment = Alignment.Center
        ) {
            if (item.thumbnailUrl != null) {
                AsyncImage(
                    model = item.thumbnailUrl,
                    contentDescription = null, // decorative: the row text names the item
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.PlayCircleFilled, null, tint = Color.Gray, modifier = Modifier.size(32.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${item.uploader} • ${item.source}",
                color = Color.Gray,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (onRemove != null) {
            IconButton(onClick = { onRemove(item) }) {
                Icon(Icons.Default.Close, "Remove ${item.title}", tint = Color.LightGray)
            }
        }
    }
}

@Composable
private fun PlaylistsPage(
    library: LibraryRepository,
    onBack: () -> Unit,
    onOpen: (com.vibely.app.data.db.PlaylistSummary) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val playlists by remember { library.playlists() }
        .collectAsStateWithLifecycle(emptyList<com.vibely.app.data.db.PlaylistSummary>())
    var showCreate by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<com.vibely.app.data.db.PlaylistSummary?>(null) }

    Column(modifier.fillMaxSize().background(Bg)) {
        PageHeader("Playlists", onBack) {
            TextButton(onClick = { showCreate = true }) { Text("New", color = Accent) }
        }
        if (playlists.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("No playlists yet. Tap New to create one.", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(playlists, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable(onClickLabel = "Open playlist ${p.name}") { onOpen(p) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PlaylistPlay, null, tint = Accent, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (p.itemCount == 1) "1 item" else "${p.itemCount} items",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { toDelete = p }) {
                            Icon(Icons.Default.Delete, "Delete playlist ${p.name}", tint = Color.LightGray)
                        }
                    }
                    HorizontalDivider(color = Color(0xFF303137))
                }
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "New playlist",
            confirmLabel = "Create",
            onConfirm = { name -> scope.launch { library.createPlaylist(name) } },
            onDismiss = { showCreate = false }
        )
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete playlist?") },
            text = { Text("“${p.name}” will be removed. The videos themselves are not deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { library.deletePlaylist(p.id) }
                    toDelete = null
                }) { Text("Delete", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
internal fun NameDialog(
    title: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(60) },
                singleLine = true,
                label = { Text("Name") }
            )
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onConfirm(name)
                    onDismiss()
                }
            ) { Text(confirmLabel, color = if (name.isNotBlank()) Accent else Color.Gray) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Offline downloads: live progress while downloading, tap a finished one to play it without internet. */
@Composable
private fun DownloadsPage(
    onBack: () -> Unit,
    onPlay: (MediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf<List<DownloadEntry>?>(null) }
    var toDelete by remember { mutableStateOf<DownloadEntry?>(null) }

    // Refresh quickly while something is downloading, slowly otherwise.
    LaunchedEffect(Unit) {
        while (true) {
            val list = DownloadsRepository.list(context)
            entries = list
            delay(if (list.any { it.status == DownloadStatus.Running || it.status == DownloadStatus.Waiting }) 1_000L else 5_000L)
        }
    }

    Column(modifier.fillMaxSize().background(Bg)) {
        PageHeader("Downloads", onBack)
        val list = entries
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
            list.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Nothing downloaded yet. Open a video and tap Download to watch it without internet.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(list, key = { it.downloadId }) { entry ->
                    DownloadRow(
                        entry = entry,
                        onClick = { entry.playable()?.let(onPlay) },
                        onDelete = { toDelete = entry }
                    )
                }
            }
        }
    }

    toDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(if (entry.status == DownloadStatus.Done) "Delete download?" else "Cancel download?") },
            text = { Text("“${entry.item.title}” will be removed from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        DownloadsRepository.remove(context, entry)
                        entries = DownloadsRepository.list(context)
                    }
                    toDelete = null
                }) { Text("Remove", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep") } }
        )
    }
}

@Composable
private fun DownloadRow(entry: DownloadEntry, onClick: () -> Unit, onDelete: () -> Unit) {
    val done = entry.status == DownloadStatus.Done
    Row(
        Modifier.fillMaxWidth()
            .clickable(enabled = done, onClickLabel = "Play ${entry.item.title}", onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(128.dp).height(72.dp).clip(RoundedCornerShape(10.dp)).background(SurfaceDark),
            contentAlignment = Alignment.Center
        ) {
            if (entry.item.thumbnailUrl != null) {
                AsyncImage(
                    model = entry.item.thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.PlayCircleFilled, null, tint = Color.Gray, modifier = Modifier.size(32.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.item.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val status = when (entry.status) {
                DownloadStatus.Done -> "Ready • ${formatBytes(entry.totalBytes)}"
                DownloadStatus.Failed -> "Download failed — remove it and try again"
                DownloadStatus.Waiting -> "Waiting for connection…"
                DownloadStatus.Running ->
                    if (entry.totalBytes > 0) "${formatBytes(entry.bytes)} of ${formatBytes(entry.totalBytes)}"
                    else "Downloading…"
            }
            Text(
                status,
                color = if (entry.status == DownloadStatus.Failed) Accent else Color.Gray,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (entry.status == DownloadStatus.Running || entry.status == DownloadStatus.Waiting) {
                Spacer(Modifier.height(6.dp))
                val progress = entry.progress
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Accent)
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Accent)
                }
            }
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, "Remove download of ${entry.item.title}", tint = Color.LightGray)
        }
    }
}

/** 1536 -> "1.5 KB"; 52_428_800 -> "50.0 MB". */
internal fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = listOf("B", "KB", "MB", "GB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024 && unit < units.lastIndex) {
        value /= 1024
        unit++
    }
    return if (unit == 0 || value >= 100) "%d %s".format(java.util.Locale.ROOT, value.toLong(), units[unit])
    else "%.1f %s".format(java.util.Locale.ROOT, value, units[unit])
}
