package com.vibely.app.data

/**
 * Small thread-safe LRU cache whose entries go stale after [ttlMs].
 * [get] returns only fresh values; [getStale] also returns expired ones (used as an offline fallback).
 */
class TtlCache<K : Any, V : Any>(
    private val maxEntries: Int,
    private val ttlMs: Long,
    private val clock: () -> Long = System::currentTimeMillis
) {
    private class Entry<T>(val value: T, val storedAt: Long)

    private val map = object : LinkedHashMap<K, Entry<V>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, Entry<V>>?): Boolean =
            size > maxEntries
    }

    @Synchronized
    fun get(key: K): V? {
        val entry = map[key] ?: return null
        return if (clock() - entry.storedAt > ttlMs) null else entry.value
    }

    @Synchronized
    fun getStale(key: K): V? = map[key]?.value

    @Synchronized
    fun put(key: K, value: V) {
        map[key] = Entry(value, clock())
    }

    @Synchronized
    fun clear() = map.clear()
}
