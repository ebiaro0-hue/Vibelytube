package com.vibely.app.data

import com.vibely.app.BuildConfig
import com.vibely.app.MediaItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

data class SearchResult(
    val items: List<MediaItem>,
    val message: String,
    val hasMore: Boolean = false,
    /** True when nothing could be loaded and there was nothing saved to fall back on. */
    val failed: Boolean = false
)

/** One track of an audio item (album, audiobook, concert). */
data class MediaTrack(val title: String, val url: String, val seconds: Int?)

/**
 * Playable file URLs for an item, best first. If the player cannot decode one, it moves on to the next.
 * [type] is "video" or "audio".
 */
data class ResolvedMedia(
    val urls: List<String>,
    val type: String,
    /** Audio albums, audiobooks and concerts: every track in play order. Empty for single files and video. */
    val tracks: List<MediaTrack> = emptyList(),
    /**
     * A web player page (Dailymotion, Vimeo, Rumble, Odysee, PeerTube) shown inside the app. Used when there is no
     * direct file ([urls] empty), or as the automatic fallback when every direct file fails to play.
     */
    val embedUrl: String? = null
) {
    val url: String get() = urls.firstOrNull() ?: embedUrl.orEmpty()
}

/** A filter chip on Home: [id] is the source id ("rumble", ...), or null for "All sites". */
data class SourceChip(val id: String?, val label: String)

val SourceChips: List<SourceChip> = listOf(
    SourceChip(null, "All"),
    SourceChip("pexels", "Pexels"),
    SourceChip("pixabay", "Pixabay"),
    SourceChip("mixkit", "Mixkit"),
    SourceChip("rumble", "Rumble"),
    SourceChip("odysee", "Odysee"),
    SourceChip("peertube", "PeerTube"),
    SourceChip("wikimedia", "Wikimedia"),
    SourceChip("dailymotion", "Dailymotion"),
    SourceChip("vimeo", "Vimeo")
)

/**
 * Where the app gets its content (the Vibely server + the phone itself, no Internet Archive).
 *
 * Two ways to read the sites, chosen by [ContentMode] (Settings → Media sources):
 *  - **The Vibely server** (when `VIBELY_BACKEND_URL` is set): `/api/videos` (Home), `/api/search`, `/api/shorts` and
 *    `/api/stream` (a fresh playable link for a video page, found at the moment you tap it). When a website changes,
 *    only the server is updated, not the app.
 *  - **The phone itself**, exactly as before: the same sites are read straight from the phone by [ExtraSources]
 *    (same ids, so both sides understand each other's items). It needs no server at all.
 *
 * In Automatic mode the server is asked first, with SHORT time limits; if it is missing, asleep or failing, the phone
 * takes over at once and the server is left alone for a few minutes ([BackendBreaker]) while [warmUp] wakes it.
 */
object VibelyRepository {
    // The server gets short time limits: a sleeping free server must not make the app wait a minute.
    private val client by lazy {
        sharedHttpClient.newBuilder()
            .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var mode: ContentMode = ContentMode.AUTO
    private val breaker = BackendBreaker()

    // Short-lived page cache: repeat searches are instant, and the last results stay readable offline.
    private val cache = TtlCache<String, SearchResult>(maxEntries = 40, ttlMs = 5 * 60_000L)
    private val resolveCache = TtlCache<String, ResolvedMedia>(maxEntries = 60, ttlMs = 30 * 60_000L)

    private val backendConfigured: Boolean
        get() = !BuildConfig.BACKEND_BASE_URL.contains("YOUR-RENDER-SERVICE")

    /** Is the server worth asking right now? (Server-only mode always asks: there is nothing else to do.) */
    private fun backendUsable(): Boolean =
        backendConfigured && when (mode) {
            ContentMode.PHONE -> false
            ContentMode.SERVER -> true
            ContentMode.AUTO -> breaker.available()
        }

    val serverConfigured: Boolean get() = backendConfigured

    /** Called when the person changes the setting: saved answers from the other way are dropped. */
    fun setMode(newMode: ContentMode) {
        mode = newMode
        breaker.reset()
        cache.clear()
        resolveCache.clear()
    }

    /**
     * Wakes a sleeping free server in the background (the first request can take ~50 s). When it answers, the
     * server is used again; until then the phone does the work.
     */
    suspend fun warmUp() {
        if (!backendConfigured || mode == ContentMode.PHONE) return
        withContext(Dispatchers.IO) {
            try {
                val url = BuildConfig.BACKEND_BASE_URL.trimEnd('/') + "/health"
                val awake = sharedHttpClient.newCall(Request.Builder().url(url).get().build()).execute().use { it.isSuccessful }
                if (awake) breaker.reset()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // still asleep or unreachable: the phone keeps working
            }
        }
    }

    private fun serverProblem(detail: String?): String =
        if (!backendConfigured) {
            "Server-only mode needs a server address (VIBELY_BACKEND_URL). Change it in Settings → Media sources."
        } else {
            "The Vibely server did not answer${detail?.let { " ($it)" } ?: ""}. " +
                "Choose Automatic in Settings → Media sources to read the sites from this phone."
        }

    /** Home feed: the newest videos of all sites, or of one site ([source]). */
    suspend fun featured(page: Int = 1, source: String? = null): SearchResult = load(
        cacheKey = "featured|${source.orEmpty()}|$page",
        backendPath = "/api/videos?page=$page" + sourceParam(source),
        device = { ExtraSources.latest(page, source) }
    )

    /** Search by title (or by a site's name) across all sites, or inside one site ([source]). */
    suspend fun search(query: String, page: Int = 1, source: String? = null): SearchResult = load(
        cacheKey = "search|${source.orEmpty()}|$query|$page",
        backendPath = "/api/search?q=" + enc(query) + "&page=$page" + sourceParam(source),
        device = { ExtraSources.search(query, page, source) }
    )

    /** Short clips for the Shorts tab (stock-footage sites are short by nature). */
    suspend fun shorts(): SearchResult = load(
        cacheKey = "shorts",
        backendPath = "/api/shorts",
        device = { deviceShorts() },
        paged = false
    )

    private suspend fun deviceShorts(): List<MediaItem> {
        val stock = setOf("pexels", "pixabay", "mixkit")
        val out = ArrayList<MediaItem>()
        for (page in 1..3) {
            out += ExtraSources.latest(page).filter { it.sourceId in stock }
            if (out.size >= 12) break
        }
        return out.distinctBy { it.key }
    }

    /** More videos from the same site as [item] (shown under the player). Empty when there are none. */
    suspend fun related(item: MediaItem): List<MediaItem> =
        featured(1, item.sourceId).items.filter { it.key != item.key }.take(12)

    /**
     * Finds a fresh playable link for an item. Throws IllegalStateException with a user-readable message.
     * [fresh] skips the saved answer (used by Retry).
     */
    suspend fun resolve(item: MediaItem, fresh: Boolean = false): ResolvedMedia = withContext(Dispatchers.IO) {
        val direct = item.mediaUrl
        if (!direct.isNullOrBlank()) {
            return@withContext ResolvedMedia(listOf(direct), item.mediaType ?: "video")
        }
        if (item.sourceId.isBlank()) throw IllegalStateException("This item has no playable media.")
        if (!fresh) resolveCache.get(item.key)?.let { return@withContext it }

        // 1) The server's stream extractor (it keeps up with site changes, so the app does not have to).
        val page = item.pageUrl
        var serverDetail: String? = null
        if (backendUsable() && !page.isNullOrBlank()) {
            try {
                val result = streamViaBackend(page)
                breaker.reset()
                resolveCache.put(item.key, result)
                return@withContext result
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                breaker.trip() // no answer at all: leave the server alone for a few minutes
                serverDetail = e.message
            } catch (e: Exception) {
                serverDetail = e.message // the server answered but found no stream: not an outage
            }
        }
        if (mode == ContentMode.SERVER) {
            throw IllegalStateException(
                if (serverDetail != null && backendConfigured) "The Vibely server could not play this video: $serverDetail"
                else serverProblem(serverDetail)
            )
        }

        // 2) The phone reads the site itself (the original way).
        val source = ExtraSources.byId(item.sourceId)
            ?: throw IllegalStateException("This video comes from a source Vibely no longer uses.")
        try {
            val result = source.resolve(item.id)
            resolveCache.put(item.key, result)
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: IllegalStateException) {
            throw e
        } catch (e: IOException) {
            throw IllegalStateException("Could not reach ${source.name}: ${e.message ?: "network error"}. Tap Retry.")
        } catch (e: Exception) {
            throw IllegalStateException("${source.name} did not give a playable video. Tap Retry or try another video.")
        }
    }

    private fun streamViaBackend(pageUrl: String): ResolvedMedia {
        val url = BuildConfig.BACKEND_BASE_URL.trimEnd('/') + "/api/stream?url=" + enc(pageUrl)
        return client.newCall(Request.Builder().url(url).get().build()).execute().use {
            val body = it.body?.string().orEmpty()
            if (!it.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrNull().orEmpty()
                throw IllegalStateException(detail.ifBlank { "Server returned HTTP ${it.code}" })
            }
            parseStream(body)
        }
    }

    /** Server first (when configured), then the phone, then the last saved copy of this page. */
    private suspend fun load(
        cacheKey: String,
        backendPath: String,
        device: suspend () -> List<MediaItem>,
        paged: Boolean = true
    ): SearchResult = withContext(Dispatchers.IO) {
        cache.get(cacheKey)?.let { return@withContext it }

        var backendError: String? = null
        var backendAnswered = false
        if (backendUsable()) {
            try {
                val result = fetchFromBackend(backendPath)
                breaker.reset()
                backendAnswered = true
                if (result.items.isNotEmpty()) {
                    val shown = result.copy(message = "${result.message} (from the Vibely server)")
                    cache.put(cacheKey, shown)
                    return@withContext shown
                }
                // An empty answer (for example the server just woke up and has not scraped yet): ask the phone too.
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                breaker.trip() // short pause: the next requests go straight to the phone
                backendError = e.message
            }
        }

        if (mode == ContentMode.SERVER) {
            return@withContext cache.getStale(cacheKey)?.copy(message = "Server unavailable — showing saved results.")
                ?: if (backendAnswered) SearchResult(emptyList(), "No results found.")
                else SearchResult(emptyList(), serverProblem(backendError), failed = true)
        }

        try {
            val items = device()
            val result = SearchResult(
                items = items,
                message = if (items.isEmpty()) "No results found." else "${items.size} results (read on this phone).",
                hasMore = paged && items.isNotEmpty()
            )
            // An empty answer is not worth keeping: the next try should ask again.
            if (items.isNotEmpty()) cache.put(cacheKey, result)
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Offline or sites down: fall back to the last copy of this page, if we have one.
            cache.getStale(cacheKey)?.copy(message = "You're offline — showing saved results.")
                ?: SearchResult(
                    emptyList(),
                    "Could not load videos: ${e.message ?: backendError ?: "network error"}. " +
                        "Check your connection and try again.",
                    failed = true
                )
        }
    }

    private fun fetchFromBackend(path: String): SearchResult {
        val url = BuildConfig.BACKEND_BASE_URL.trimEnd('/') + path
        return client.newCall(Request.Builder().url(url).get().build()).execute().use {
            if (!it.isSuccessful) throw IllegalStateException("Backend returned HTTP ${it.code}")
            parseBackendFeed(it.body?.string() ?: "{}")
        }
    }

    private fun sourceParam(source: String?): String = if (source.isNullOrBlank()) "" else "&source=" + enc(source)

    private fun enc(value: String): String = java.net.URLEncoder.encode(value, "UTF-8")
}

/** The server's list answer (`/api/videos`, `/api/search`, `/api/shorts`). */
internal fun parseBackendFeed(json: String): SearchResult {
    val root = JSONObject(json)
    val array = root.optJSONArray("items")
    val result = mutableListOf<MediaItem>()
    if (array != null) {
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result += MediaItem(
                id = obj.optString("id", "item-$i"),
                title = obj.optString("title", "Untitled"),
                uploader = obj.optString("uploader", "Unknown"),
                thumbnailUrl = obj.optStringOrNull("thumbnail_url"),
                duration = obj.optStringOrNull("duration") ?: "",
                source = obj.optString("source", "Unknown"),
                sourceId = obj.optString("source_id", ""),
                mediaType = obj.optStringOrNull("media_type"),
                pageUrl = obj.optStringOrNull("page_url"),
                mediaUrl = obj.optStringOrNull("media_url")
            )
        }
    }
    return SearchResult(
        items = result,
        message = root.optString("message", "Done."),
        hasMore = root.optBoolean("has_more", false)
    )
}

/** The server's `/api/stream` answer: direct links (best first) and/or the site's own web player. */
internal fun parseStream(json: String): ResolvedMedia {
    val o = JSONObject(json)
    val urls = ArrayList<String>()
    val arr = o.optJSONArray("media_urls")
    if (arr != null) {
        for (i in 0 until arr.length()) {
            val u = arr.optString(i)
            if (u.startsWith("https://")) urls += u
        }
    }
    if (urls.isEmpty()) o.optStringOrNull("media_url")?.takeIf { it.startsWith("https://") }?.let { urls += it }
    val embed = o.optStringOrNull("embed_url")?.takeIf { it.startsWith("https://") }
    if (urls.isEmpty() && embed == null) {
        throw IllegalStateException("The server found no playable stream for this video.")
    }
    return ResolvedMedia(urls, o.optStringOrNull("media_type") ?: "video", embedUrl = embed)
}

// org.json returns the string "null" for JSON nulls via optString, so handle that explicitly.
private fun JSONObject.optStringOrNull(key: String): String? {
    if (isNull(key)) return null
    return optString(key).takeIf { it.isNotBlank() }
}
