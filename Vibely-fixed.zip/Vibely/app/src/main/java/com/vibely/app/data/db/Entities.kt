package com.vibely.app.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Snapshot of an item's metadata, so Library lists work offline and without calling the backend. */
@Entity(tableName = "media_items", primaryKeys = ["sourceId", "id"])
data class MediaEntity(
    val sourceId: String,
    val id: String,
    val title: String,
    val uploader: String,
    val thumbnailUrl: String?,
    val duration: String,
    val source: String,
    val mediaType: String?,
    val pageUrl: String?,
    val mediaUrl: String?
)

@Entity(tableName = "history", primaryKeys = ["sourceId", "id"])
data class HistoryEntity(
    val sourceId: String,
    val id: String,
    val watchedAt: Long
)

@Entity(tableName = "likes", primaryKeys = ["sourceId", "id"])
data class LikeEntity(
    val sourceId: String,
    val id: String,
    val createdAt: Long
)

@Entity(tableName = "saved", primaryKeys = ["sourceId", "id"])
data class SavedEntity(
    val sourceId: String,
    val id: String,
    val createdAt: Long
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
    /** Stable id shared across devices (Firestore document id). */
    val cloudId: String = ""
)

@Entity(
    tableName = "playlist_items",
    primaryKeys = ["playlistId", "sourceId", "id"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId")]
)
data class PlaylistItemEntity(
    val playlistId: Long,
    val sourceId: String,
    val id: String,
    val addedAt: Long
)

/** Query result (not a table). */
data class PlaylistSummary(
    val id: Long,
    val name: String,
    val itemCount: Int
)

/** A media snapshot plus the time it was liked / saved / watched / added (used for cloud sync). */
data class TimedMedia(
    @Embedded val media: MediaEntity,
    val ts: Long
)
