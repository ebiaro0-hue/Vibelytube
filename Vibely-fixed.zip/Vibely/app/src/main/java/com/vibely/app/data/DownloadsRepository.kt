package com.vibely.app.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.vibely.app.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class DownloadStatus { Waiting, Running, Done, Failed }

/** One saved-for-offline item, with live progress from Android's DownloadManager. */
data class DownloadEntry(
    val item: MediaItem,
    val downloadId: Long,
    val fileName: String,
    val status: DownloadStatus,
    val bytes: Long,
    val totalBytes: Long,
    /** file:// address of the finished file; null until the download is done. */
    val localUri: String?
) {
    val progress: Float? get() = if (totalBytes > 0) (bytes.toFloat() / totalBytes).coerceIn(0f, 1f) else null

    /** The item with its offline file as the media address, so the player never touches the network. */
    fun playable(): MediaItem? = localUri?.let { item.copy(mediaUrl = it) }
}

/**
 * Offline downloads of direct video/audio files (videos that only play in a site's web player have no file to save).
 *
 * Android's DownloadManager does the transfer (notification, retries, resume after a lost connection);
 * files live in the app's own storage, so no storage permission is needed and uninstalling removes them.
 * A small list in SharedPreferences remembers which item each download belongs to.
 */
object DownloadsRepository {
    private const val PREFS = "vibely_downloads"
    private const val KEY = "entries"
    private const val USER_AGENT = "Vibely/0.11 (Android)"

    private class Stored(
        val item: MediaItem,
        val downloadId: Long,
        val fileName: String
    )

    private fun manager(context: Context) =
        context.applicationContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private fun dirType(item: MediaItem) =
        if (item.mediaType == "audio") Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES

    private fun fileFor(context: Context, item: MediaItem, fileName: String): File? =
        context.applicationContext.getExternalFilesDir(dirType(item))?.let { File(File(it, "Vibely"), fileName) }

    // ---- persistence ----

    private fun readStored(context: Context): List<Stored> {
        val raw = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                Stored(
                    item = MediaItem(
                        id = o.getString("id"),
                        title = o.optString("title"),
                        uploader = o.optString("uploader"),
                        thumbnailUrl = o.optString("thumb").takeIf { it.isNotBlank() },
                        duration = o.optString("duration"),
                        source = o.optString("source"),
                        sourceId = o.optString("sourceId"),
                        mediaType = o.optString("type").takeIf { it.isNotBlank() },
                        pageUrl = o.optString("page").takeIf { it.isNotBlank() }
                    ),
                    downloadId = o.getLong("downloadId"),
                    fileName = o.getString("fileName")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun writeStored(context: Context, list: List<Stored>) {
        val array = JSONArray()
        list.forEach { s ->
            array.put(
                JSONObject()
                    .put("id", s.item.id)
                    .put("title", s.item.title)
                    .put("uploader", s.item.uploader)
                    .put("thumb", s.item.thumbnailUrl ?: "")
                    .put("duration", s.item.duration)
                    .put("source", s.item.source)
                    .put("sourceId", s.item.sourceId)
                    .put("type", s.item.mediaType ?: "")
                    .put("page", s.item.pageUrl ?: "")
                    .put("downloadId", s.downloadId)
                    .put("fileName", s.fileName)
            )
        }
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    // ---- public API ----

    /** Current downloads, newest first, with up-to-date progress. Entries whose file vanished are dropped. */
    suspend fun list(context: Context): List<DownloadEntry> = withContext(Dispatchers.IO) {
        val stored = readStored(context)
        if (stored.isEmpty()) return@withContext emptyList()

        val dm = manager(context)
        class Row(val status: Int, val bytes: Long, val total: Long, val localUri: String?)
        val rows = HashMap<Long, Row>()
        runCatching {
            dm.query(DownloadManager.Query().setFilterById(*stored.map { it.downloadId }.toLongArray())).use { c ->
                val idCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val statusCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val doneCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val totalCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val uriCol = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)
                while (c.moveToNext()) {
                    rows[c.getLong(idCol)] = Row(
                        c.getInt(statusCol), c.getLong(doneCol), c.getLong(totalCol), c.getString(uriCol)
                    )
                }
            }
        }

        val kept = ArrayList<Stored>()
        val result = ArrayList<DownloadEntry>()
        for (s in stored) {
            val row = rows[s.downloadId]
            val file = fileFor(context, s.item, s.fileName)
            val entry = when {
                row != null -> {
                    val status = when (row.status) {
                        DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.Done
                        DownloadManager.STATUS_FAILED -> DownloadStatus.Failed
                        DownloadManager.STATUS_RUNNING -> DownloadStatus.Running
                        else -> DownloadStatus.Waiting // pending or paused (e.g. waiting for a connection)
                    }
                    val uri = if (status == DownloadStatus.Done) {
                        row.localUri ?: file?.takeIf { it.exists() }?.let { Uri.fromFile(it).toString() }
                    } else null
                    // A finished download whose file was deleted outside the app is not a download any more.
                    if (status == DownloadStatus.Done && uri == null) null
                    else DownloadEntry(s.item, s.downloadId, s.fileName, status, row.bytes, row.total, uri)
                }
                // DownloadManager forgot it (cleared its data) but the file is still here.
                file != null && file.exists() && file.length() > 0 ->
                    DownloadEntry(s.item, s.downloadId, s.fileName, DownloadStatus.Done, file.length(), file.length(), Uri.fromFile(file).toString())
                else -> null
            }
            if (entry != null) {
                kept += s
                result += entry
            }
        }
        if (kept.size != stored.size) writeStored(context, kept)
        result.reversed()
    }

    /** True when [item] is already downloaded or is downloading right now. */
    suspend fun has(context: Context, item: MediaItem): Boolean =
        list(context).any { it.item.key == item.key && it.status != DownloadStatus.Failed }

    /**
     * Starts downloading the best file of [item] ([resolved].urls.first()). Returns false if it is
     * already downloaded or downloading. Throws IllegalStateException with a readable message otherwise.
     */
    suspend fun start(context: Context, item: MediaItem, resolved: ResolvedMedia): Boolean = withContext(Dispatchers.IO) {
        if (has(context, item)) return@withContext false
        val url = resolved.urls.firstOrNull() ?: throw IllegalStateException("No file to download.")
        if (!url.startsWith("https://")) throw IllegalStateException("Only secure (https) files can be downloaded.")

        val remoteName = Uri.decode(url.substringAfterLast('/').substringBefore('?'))
        val fileName = downloadFileName(item.id, remoteName)
        val storedItem = item.copy(mediaUrl = null, mediaType = resolved.type)

        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(item.title)
            .setDescription("Vibely")
            .addRequestHeader("User-Agent", USER_AGENT)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context.applicationContext, dirType(storedItem), "Vibely/$fileName")
        val id = try {
            manager(context).enqueue(request)
        } catch (e: Exception) {
            throw IllegalStateException("Could not start the download: ${e.message ?: "unknown error"}")
        }
        // A failed earlier attempt for the same item is replaced.
        val others = readStored(context).filter { it.item.key != item.key }
        writeStored(context, others + Stored(storedItem, id, fileName))
        true
    }

    /** Cancels or deletes a download, including its file. */
    suspend fun remove(context: Context, entry: DownloadEntry) = withContext(Dispatchers.IO) {
        runCatching { manager(context).remove(entry.downloadId) }
        fileFor(context, entry.item, entry.fileName)?.let { runCatching { it.delete() } }
        writeStored(context, readStored(context).filter { it.downloadId != entry.downloadId })
    }
}
