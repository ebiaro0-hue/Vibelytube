package com.vibely.app.data

import androidx.room.withTransaction
import com.vibely.app.MediaItem
import com.vibely.app.data.db.VibelyDatabase
import com.vibely.app.data.db.HistoryEntity
import com.vibely.app.data.db.LikeEntity
import com.vibely.app.data.db.MediaEntity
import com.vibely.app.data.db.PlaylistEntity
import com.vibely.app.data.db.PlaylistItemEntity
import com.vibely.app.data.db.PlaylistSummary
import com.vibely.app.data.db.SavedEntity
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

data class SyncSummary(val likes: Int, val saved: Int, val history: Int, val playlists: Int)

/**
 * Local (on-device) library: history, likes, saved items and playlists.
 * Room is the source of truth for the UI; when signed in, changes are also written to Firestore via [cloud].
 */
class LibraryRepository(
    private val db: VibelyDatabase,
    private val cloud: CloudSync
) {
    private val dao = db.library()

    // ---- history ----
    suspend fun recordWatched(item: MediaItem) {
        val t = now()
        db.withTransaction {
            dao.upsertMedia(item.toEntity())
            dao.upsertHistory(HistoryEntity(item.sourceId, item.id, t))
        }
        cloud.pushHistory(item, t)
    }

    fun history(): Flow<List<MediaItem>> = dao.history().map { list -> list.map { it.toItem() } }

    suspend fun clearHistory() {
        dao.clearHistory()
        cloud.clearHistory()
    }

    suspend fun removeFromHistory(item: MediaItem) {
        dao.removeHistory(item.sourceId, item.id)
        cloud.removeHistory(item)
    }

    // ---- likes ----
    fun isLiked(item: MediaItem): Flow<Boolean> = dao.isLiked(item.sourceId, item.id)
    fun liked(): Flow<List<MediaItem>> = dao.liked().map { list -> list.map { it.toItem() } }

    suspend fun setLiked(item: MediaItem, liked: Boolean) {
        val t = now()
        db.withTransaction {
            if (liked) {
                dao.upsertMedia(item.toEntity())
                dao.insertLike(LikeEntity(item.sourceId, item.id, t))
            } else {
                dao.deleteLike(item.sourceId, item.id)
            }
        }
        if (liked) cloud.pushLike(item, t) else cloud.removeLike(item)
    }

    // ---- saved ----
    fun isSaved(item: MediaItem): Flow<Boolean> = dao.isSaved(item.sourceId, item.id)
    fun saved(): Flow<List<MediaItem>> = dao.saved().map { list -> list.map { it.toItem() } }

    suspend fun setSaved(item: MediaItem, saved: Boolean) {
        val t = now()
        db.withTransaction {
            if (saved) {
                dao.upsertMedia(item.toEntity())
                dao.insertSaved(SavedEntity(item.sourceId, item.id, t))
            } else {
                dao.deleteSaved(item.sourceId, item.id)
            }
        }
        if (saved) cloud.pushSaved(item, t) else cloud.removeSaved(item)
    }

    // ---- playlists ----
    fun playlists(): Flow<List<PlaylistSummary>> = dao.playlists()

    fun playlistItems(playlistId: Long): Flow<List<MediaItem>> =
        dao.playlistItems(playlistId).map { list -> list.map { it.toItem() } }

    /** Returns the new playlist id, or null if the name is blank. */
    suspend fun createPlaylist(name: String): Long? {
        val clean = name.trim().take(60)
        if (clean.isEmpty()) return null
        val t = now()
        val cloudId = UUID.randomUUID().toString()
        val id = dao.insertPlaylist(PlaylistEntity(name = clean, createdAt = t, cloudId = cloudId))
        cloud.pushPlaylist(cloudId, clean, t)
        return id
    }

    suspend fun deletePlaylist(playlistId: Long) {
        val cloudId = dao.playlistById(playlistId)?.cloudId
        dao.deletePlaylist(playlistId)
        if (!cloudId.isNullOrEmpty()) cloud.deletePlaylist(cloudId)
    }

    suspend fun addToPlaylist(playlistId: Long, item: MediaItem) {
        val t = now()
        db.withTransaction {
            dao.upsertMedia(item.toEntity())
            dao.insertPlaylistItem(PlaylistItemEntity(playlistId, item.sourceId, item.id, t))
        }
        val cloudId = dao.playlistById(playlistId)?.cloudId
        if (!cloudId.isNullOrEmpty()) cloud.pushPlaylistItem(cloudId, item, t)
    }

    suspend fun removeFromPlaylist(playlistId: Long, item: MediaItem) {
        dao.deletePlaylistItem(playlistId, item.sourceId, item.id)
        val cloudId = dao.playlistById(playlistId)?.cloudId
        if (!cloudId.isNullOrEmpty()) cloud.removePlaylistItem(cloudId, item)
    }

    // ---- local wipe ----
    suspend fun clearLocal() {
        db.withTransaction {
            dao.clearHistory()
            dao.clearLikes()
            dao.clearSaved()
            dao.clearPlaylists() // playlist_items are removed by ON DELETE CASCADE
            dao.clearMedia()
        }
    }

    // ---- cloud sync ----

    /**
     * Two-way merge with the signed-in account:
     *  1. read the cloud library (fails if offline),
     *  2. add anything the cloud has that this device lacks,
     *  3. upload anything this device has that the cloud lacks.
     * Deletions made while offline are not propagated (they are re-added by the merge).
     * If a different account than last time signs in, the previous account's local data is cleared first
     * so it is never uploaded into the new account.
     */
    suspend fun syncNow(): SyncSummary {
        val uid = cloud.currentUid() ?: throw IllegalStateException("Sign in first.")
        val last = cloud.lastSyncedUid()
        if (last != null && last != uid) clearLocal()

        val snap = cloud.fetch()

        // cloud -> local
        db.withTransaction {
            snap.likes.forEach {
                dao.upsertMedia(it.item.toEntity())
                dao.insertLikeIfAbsent(LikeEntity(it.item.sourceId, it.item.id, it.time))
            }
            snap.saved.forEach {
                dao.upsertMedia(it.item.toEntity())
                dao.insertSavedIfAbsent(SavedEntity(it.item.sourceId, it.item.id, it.time))
            }
            snap.history.forEach {
                dao.upsertMedia(it.item.toEntity())
                dao.insertHistoryIfAbsent(HistoryEntity(it.item.sourceId, it.item.id, it.time))
            }
            snap.playlists.forEach { cp ->
                val localId = dao.playlistByCloudId(cp.cloudId)?.id
                    ?: dao.insertPlaylist(PlaylistEntity(name = cp.name, createdAt = cp.createdAt, cloudId = cp.cloudId))
                cp.items.forEach {
                    dao.upsertMedia(it.item.toEntity())
                    dao.insertPlaylistItemIfAbsent(PlaylistItemEntity(localId, it.item.sourceId, it.item.id, it.time))
                }
            }
        }

        // local -> cloud (only what the cloud is missing)
        val tasks = mutableListOf<Task<Void>>()
        val cloudLikes = snap.likes.map { it.item.key }.toSet()
        val cloudSaved = snap.saved.map { it.item.key }.toSet()
        val cloudHistory = snap.history.map { it.item.key }.toSet()
        dao.likesTimed().filter { it.media.key() !in cloudLikes }
            .forEach { cloud.pushLike(it.media.toItem(), it.ts)?.let(tasks::add) }
        dao.savedTimed().filter { it.media.key() !in cloudSaved }
            .forEach { cloud.pushSaved(it.media.toItem(), it.ts)?.let(tasks::add) }
        dao.historyTimed().filter { it.media.key() !in cloudHistory }
            .forEach { cloud.pushHistory(it.media.toItem(), it.ts)?.let(tasks::add) }

        val cloudPlaylists = snap.playlists.associateBy { it.cloudId }
        dao.playlistsList().forEach { p ->
            if (p.cloudId.isEmpty()) return@forEach
            val remote = cloudPlaylists[p.cloudId]
            if (remote == null) cloud.pushPlaylist(p.cloudId, p.name, p.createdAt)?.let(tasks::add)
            val remoteKeys = remote?.items?.map { it.item.key }?.toSet() ?: emptySet()
            dao.playlistItemsTimed(p.id).filter { it.media.key() !in remoteKeys }
                .forEach { cloud.pushPlaylistItem(p.cloudId, it.media.toItem(), it.ts)?.let(tasks::add) }
        }
        cloud.awaitAll(tasks)
        cloud.setLastSyncedUid(uid)

        return SyncSummary(
            likes = dao.likesTimed().size,
            saved = dao.savedTimed().size,
            history = dao.historyTimed().size,
            playlists = dao.playlistsList().size
        )
    }

    private fun now() = System.currentTimeMillis()
}

private fun MediaEntity.key() = "$sourceId:$id"

private fun MediaItem.toEntity() = MediaEntity(
    sourceId = sourceId,
    id = id,
    title = title,
    uploader = uploader,
    thumbnailUrl = thumbnailUrl,
    duration = duration,
    source = source,
    mediaType = mediaType,
    pageUrl = pageUrl,
    mediaUrl = mediaUrl
)

private fun MediaEntity.toItem() = MediaItem(
    id = id,
    title = title,
    uploader = uploader,
    thumbnailUrl = thumbnailUrl,
    duration = duration,
    source = source,
    sourceId = sourceId,
    mediaType = mediaType,
    pageUrl = pageUrl,
    mediaUrl = mediaUrl
)
