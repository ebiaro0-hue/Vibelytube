package com.vibely.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Guest mode: anyone can open Vibely, search and watch videos without an account.
 * Liking, saving, playlists, downloads and the personal library need a signed-in account.
 * Comments are not built yet.
 */

/** Shown when a guest taps something that needs an account. [action] completes "Sign in to …". */
@Composable
fun SignInPromptDialog(action: String, onSignIn: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sign in required") },
        text = { Text("Sign in to $action. You can keep watching videos without an account.") },
        confirmButton = { TextButton(onClick = onSignIn) { Text("Sign in", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Not now") } }
    )
}

/** Library tab content for guests. */
@Composable
fun GuestLibraryPrompt(modifier: Modifier = Modifier, onSignIn: () -> Unit) {
    Column(
        modifier.fillMaxSize().background(Bg).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Lock, null, tint = Accent, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(16.dp))
        Text(
            "Sign in to use your library",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "History, liked videos, saved videos and playlists are available with an account. " +
                "You can keep searching and watching without one.",
            color = Color.LightGray,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(22.dp))
        Button(onClick = onSignIn, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Text("Sign in or create account")
        }
    }
}
