"""Stage 2 "Cron job": the scheduled scrape, plus the live search used by /api/search."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Dict, List, Sequence, Tuple

from app.db import Store
from app.scraping.models import Entry
from app.scraping.sites import PER_PAGE, Site

log = logging.getLogger("vibely.jobs")

PAGES_PER_RUN = 2
LIVE_SEARCH_TIMEOUT = 12.0
RECENT_DAYS = 30


def recent_only(entries: Sequence[Entry]) -> List[Entry]:
    """Strictly keep videos with a publication date within the last 30 days (and not dated in the future)."""
    today = datetime.now(timezone.utc).date()
    cutoff = today - timedelta(days=RECENT_DAYS)
    latest = today + timedelta(days=1)
    kept = []
    for entry in entries:
        if not entry.published_date:
            continue
        try:
            published = datetime.fromisoformat(entry.published_date[:10]).date()
        except ValueError:
            continue
        if cutoff <= published <= latest:
            kept.append(entry)
    return kept


def pages_for(site: Site, run: int) -> List[int]:
    """Topic-based sites get a different topic every run; API-style sites just refresh their first pages."""
    if site.topic_based:
        return [run * PAGES_PER_RUN + i + 1 for i in range(PAGES_PER_RUN)]
    return [i + 1 for i in range(PAGES_PER_RUN)]


def interleave(lists: Sequence[Sequence[Entry]]) -> List[Entry]:
    """Round-robin merge; duplicates (same site + id) are dropped."""
    out: List[Entry] = []
    seen = set()
    i = 0
    while any(i < len(items) for items in lists):
        for items in lists:
            if i < len(items):
                key = (items[i].source_id, items[i].video_id)
                if key not in seen:
                    seen.add(key)
                    out.append(items[i])
        i += 1
    return out


def scrape_all(store: Store, sites: Sequence[Site], run: int = 0, limit: int = PER_PAGE, workers: int = 5) -> Dict[str, dict]:
    """Reads the newest videos of every site and stores them. One site failing never stops the others."""
    summary: Dict[str, dict] = {s.source_id: {"count": 0, "error": None} for s in sites}

    def work(site: Site, page: int) -> Tuple[str, List[Entry], str, int]:
        try:
            found = list(site.latest(page, limit))
            kept = recent_only(found)
            return site.source_id, kept, "", len(found) - len(kept)
        except Exception as exc:
            return site.source_id, [], str(exc) or exc.__class__.__name__, 0

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(work, site, page) for site in sites for page in pages_for(site, run)]
        results = [f.result() for f in futures]

    for site in sites:
        entries: List[Entry] = []
        errors: List[str] = []
        skipped = 0
        for source_id, found, error, dropped in results:
            if source_id != site.source_id:
                continue
            entries += found
            skipped += dropped
            if error:
                errors.append(error)
        stored = store.upsert(entries)
        if stored == 0 and skipped and not errors:
            # The site answered, but every video was undated or older than 30 days: say so instead of a silent "ok, 0".
            errors.append(f"{skipped} videos read, none dated within the last {RECENT_DAYS} days")
        ok = stored > 0 or not errors
        error_text = None if ok else "; ".join(dict.fromkeys(errors))[:300]
        store.set_status(site.source_id, ok, stored, error_text)
        summary[site.source_id] = {"count": stored, "error": error_text}
        if error_text:
            log.warning("scrape %s failed: %s", site.source_id, error_text)
    return summary


def search_live(sites: Sequence[Site], query: str, page: int, limit: int = PER_PAGE,
                timeout: float = LIVE_SEARCH_TIMEOUT) -> Tuple[List[List[Entry]], List[str]]:
    """Asks the sites at the same time. Slow or failing sites are left out and named in the second result."""
    if not sites:
        return [], []
    pool = ThreadPoolExecutor(max_workers=len(sites))
    futures = {pool.submit(site.search, query, page, limit): site for site in sites}
    done, not_done = wait(list(futures), timeout=timeout)
    pool.shutdown(wait=False, cancel_futures=True)
    lists: List[List[Entry]] = []
    failed: List[str] = [futures[f].name for f in not_done]
    for site in sites:
        future = next((f for f, s in futures.items() if s is site), None)
        if future in done:
            try:
                lists.append(recent_only(future.result()))
            except Exception as exc:
                log.warning("search %s failed: %s", site.source_id, exc)
                failed.append(site.name)
    return lists, failed
