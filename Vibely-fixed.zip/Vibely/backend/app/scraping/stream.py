"""Stage 3: the live stream extractor ("like NewPipe", but only for an allowlist of sites).

A stream link (.mp4 / .m3u8) usually stops working after a few hours, so Vibely never stores one. When someone taps a
video the app sends the video's *page* address to ``/api/stream`` and this module finds a fresh, playable link at
that moment:

1. the site's own extractor (``sites.py``) - fast and specific;
2. if that finds nothing, yt-dlp (a maintained open-source extractor) - **only for allowlisted websites**, so a site
   change is fixed by updating the server, not the app.

Hard limits, on purpose: YouTube is blocked (it does not allow this and uses protections that this project does not
work around); DRM-protected formats are skipped; nothing here logs in, solves captchas or changes who we are.
"""
from __future__ import annotations

import os
from typing import Callable, List, Optional
from urllib.parse import urlparse

from .models import StreamInfo
from .polite import USER_AGENT
from .sites import SiteError, _distinct, quality_order, site_for_host

BLOCKED_HOSTS = ("youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com", "ytimg.com", "ggpht.com")
STREAM_TTL_SECONDS = 1800


class StreamError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def host_blocked(host: str) -> bool:
    host = host.lower()
    return any(host == b or host.endswith("." + b) for b in BLOCKED_HOSTS)


def extra_hosts() -> List[str]:
    """Extra websites (comma separated, env ``EXTRA_STREAM_HOSTS``) the server owner chose to allow through yt-dlp."""
    return [h.strip().lower() for h in os.environ.get("EXTRA_STREAM_HOSTS", "").split(",") if h.strip()]


def pick_from_info(info: dict) -> StreamInfo:
    """Chooses playable links from a yt-dlp result: progressive mp4 first, then HLS. Skips DRM and video-only files."""
    formats = [f for f in (info.get("formats") or []) if isinstance(f, dict)]

    def usable(f: dict) -> bool:
        return str(f.get("url", "")).startswith("https://") and not f.get("has_drm") and f.get("vcodec") != "none"

    def height(f: dict) -> int:
        return int(f.get("height") or 0)

    progressive = [f for f in formats if usable(f) and f.get("acodec") != "none"
                   and f.get("protocol") in ("https", "http") and f.get("ext") == "mp4"]
    hls = [f for f in formats if usable(f) and str(f.get("protocol", "")).startswith("m3u8")]
    progressive.sort(key=lambda f: quality_order(height(f)))
    hls.sort(key=lambda f: quality_order(height(f)))
    urls = [f["url"] for f in progressive] + [f["url"] for f in hls]
    top = info.get("url")
    if not urls and isinstance(top, str) and top.startswith("https://") and not info.get("has_drm"):
        urls.append(top)
    return StreamInfo(urls=_distinct(urls)[:4])


def ytdlp_info(url: str) -> dict:
    """Asks yt-dlp about one page. Imported lazily: the rest of the server works without it."""
    try:
        import yt_dlp  # type: ignore
    except ImportError as exc:
        raise StreamError("The extractor library (yt-dlp) is not installed on this server.", 501) from exc
    options = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "socket_timeout": 10,
        "http_headers": {"User-Agent": USER_AGENT},
        # Site-specific extractors only: never the "generic" one that guesses on arbitrary pages.
        "allowed_extractors": ["default", "-generic"],
    }
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            return ydl.extract_info(url, download=False) or {}
    except Exception as exc:
        raise StreamError("Could not get a playable stream for this video.", 502) from exc


def _payload(source_id: str, info: StreamInfo) -> dict:
    return {
        "source_id": source_id,
        "media_url": info.urls[0] if info.urls else None,
        "media_urls": info.urls,
        "media_type": info.media_type,
        "embed_url": info.embed_url,
        "ttl_seconds": STREAM_TTL_SECONDS,
    }


def resolve_stream(url: str, ytdlp: Callable[[str], dict] = ytdlp_info) -> dict:
    """Finds a fresh playable link (or web-player address) for a video page. Raises :class:`StreamError`."""
    parsed = urlparse((url or "").strip())
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or not host:
        raise StreamError("Only https video addresses are supported.", 400)
    if host_blocked(host):
        raise StreamError("This website is not supported by Vibely.", 403)

    site = site_for_host(host)
    site_error: Optional[str] = None
    if site is not None:
        try:
            info = site.resolve_url(url)
            if info.urls or info.embed_url:
                return _payload(site.source_id, info)
        except SiteError as exc:
            site_error = str(exc)
        except Exception as exc:  # the site did not answer, blocked us, changed its layout ...
            site_error = f"{site.name} did not answer: {exc}"
    elif host not in extra_hosts():
        raise StreamError("This website is not on the allowed list.", 403)

    try:
        picked = pick_from_info(ytdlp(url))
    except StreamError as exc:
        raise StreamError(site_error or str(exc), exc.status) from exc
    if not picked.urls:
        raise StreamError(site_error or "No playable stream was found for this video.", 404)
    return _payload(site.source_id if site else host, picked)
