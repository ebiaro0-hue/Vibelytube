"""Polite fetching: robots.txt is honoured, requests to one site are spaced out, timeouts are short.

Nothing here logs in, solves captchas, bypasses signatures/DRM or hides who we are: the User-Agent
says what this is, and a site that says "no" in robots.txt (or answers with an error) is simply skipped.
"""
from __future__ import annotations

import re
import threading
import time
from typing import Callable, Dict, Optional, Tuple
from urllib.parse import urlparse

USER_AGENT = "Mozilla/5.0 (compatible; VibelyBot/1.0; polite video indexer; respects robots.txt)"
MAX_BODY_CHARS = 2_000_000


class FetchError(Exception):
    """A page could not be read (blocked by robots.txt, HTTP error, timeout...). The message is user-readable."""


# ---------------------------------------------------------------------------------------------
# robots.txt
# ---------------------------------------------------------------------------------------------

def _pattern_matches(pattern: str, path: str) -> bool:
    anchored = pattern.endswith("$")
    body = pattern[:-1] if anchored else pattern
    regex = "^" + ".*".join(re.escape(part) for part in body.split("*")) + ("$" if anchored else "")
    return re.search(regex, path) is not None


def robots_allows(robots_txt: str, path: str) -> bool:
    """Minimal robots.txt reader.

    Rules written for our own name (VibelyBot) apply if there are any, otherwise those of ``User-agent: *``;
    the longest matching rule wins and
    Allow beats Disallow on a tie. An empty / missing file allows everything.
    """
    in_star = in_own = False
    prev_was_agent = False
    star_rules: list[Tuple[bool, str]] = []
    own_rules: list[Tuple[bool, str]] = []
    for raw in robots_txt.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        value = value.strip()
        if key == "user-agent":
            if not prev_was_agent:
                in_star = in_own = False
            if value == "*":
                in_star = True
            elif value.lower().startswith("vibelybot"):
                in_own = True
            prev_was_agent = True
        elif key in ("allow", "disallow"):
            prev_was_agent = False
            if value:
                if in_own:
                    own_rules.append((key == "allow", value))
                if in_star:
                    star_rules.append((key == "allow", value))
        else:
            prev_was_agent = False
    # Standard behaviour: a group written for our own name replaces the "*" group (they are not mixed).
    rules = own_rules or star_rules
    best: Optional[Tuple[bool, str]] = None
    for allow, pattern in rules:
        if not _pattern_matches(pattern, path):
            continue
        if best is None or len(pattern) > len(best[1]) or (len(pattern) == len(best[1]) and allow):
            best = (allow, pattern)
    return True if best is None else best[0]


# ---------------------------------------------------------------------------------------------
# Spacing + robots cache
# ---------------------------------------------------------------------------------------------

ROBOTS_TTL_SECONDS = 6 * 3600     # the server runs for days: a site's robots.txt is read again every 6 hours
ROBOTS_RETRY_SECONDS = 300        # ... and again after 5 minutes if it could not be read


class Politeness:
    def __init__(self, min_gap_seconds: float = 0.4, clock: Callable[[], float] = time.monotonic,
                 sleep: Callable[[float], None] = time.sleep):
        self.min_gap = min_gap_seconds
        self._clock = clock
        self._sleep = sleep
        self._last: Dict[str, float] = {}
        self._robots: Dict[str, Tuple[str, float]] = {}   # host -> (robots.txt text, valid until)
        self._lock = threading.Lock()

    def wait_turn(self, host: str) -> float:
        """Blocks until at least ``min_gap`` seconds passed since the last request to ``host``. Returns the wait."""
        with self._lock:
            now = self._clock()
            slot = max(now, self._last.get(host, 0.0) + self.min_gap)
            self._last[host] = slot
            delay = slot - now
        if delay > 0:
            self._sleep(delay)
        return delay

    def allowed(self, url: str, get_robots: Callable[[str], Optional[str]]) -> bool:
        parsed = urlparse(url)
        host = parsed.netloc
        with self._lock:
            entry = self._robots.get(host)
        if entry is None or self._clock() >= entry[1]:
            ttl = ROBOTS_TTL_SECONDS
            try:
                fetched = get_robots(f"https://{host}/robots.txt") or ""
            except Exception:
                fetched = ""  # no robots.txt / unreachable: everything is allowed (but we look again soon)
                ttl = ROBOTS_RETRY_SECONDS
            with self._lock:
                self._robots[host] = (fetched, self._clock() + ttl)
            cached = fetched
        else:
            cached = entry[0]
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        return robots_allows(cached, path)


POLITE = Politeness()

_client = None
_client_lock = threading.Lock()


def _http():
    """One shared httpx client (imported lazily so the pure parsing code never needs httpx)."""
    global _client
    with _client_lock:
        if _client is None:
            import httpx

            _client = httpx.Client(
                headers={"User-Agent": USER_AGENT, "Accept-Language": "en"},
                timeout=httpx.Timeout(10.0, connect=8.0),
                follow_redirects=True,
            )
        return _client


def _get_robots(url: str) -> Optional[str]:
    response = _http().get(url)
    return response.text[:200_000] if response.status_code == 200 else ""


def fetch_text(url: str, *, scrape: bool = False, headers: Optional[dict] = None,
               json_body: Optional[dict] = None, polite: Politeness = POLITE) -> str:
    """GET (or POST json) as text. ``scrape=True`` means "this is a web page": robots.txt is checked first."""
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise FetchError("Only https addresses are read.")
    if scrape and not polite.allowed(url, _get_robots):
        raise FetchError(f"{parsed.netloc} does not allow automatic reading of this page.")
    polite.wait_turn(parsed.netloc)
    try:
        client = _http()
        if json_body is not None:
            response = client.post(url, json=json_body, headers=headers)
        else:
            response = client.get(url, headers=headers)
    except Exception as exc:  # timeout, DNS, TLS ...
        raise FetchError(f"Could not reach {parsed.netloc}: {exc}") from exc
    if response.status_code >= 400:
        raise FetchError(f"{parsed.netloc} returned HTTP {response.status_code}.")
    return response.text[:MAX_BODY_CHARS]
